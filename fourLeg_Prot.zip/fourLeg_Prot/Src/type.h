/*
 * state.h
 *
 *  Created on: 2019/01/04
 *      Author: Sano
 */

#ifndef TYPE_H_
#define TYPE_H_

typedef struct{
	double x;
	double y;
	double z;
}threeDimVec;

threeDimVec iv3Dvec(double x, double y, double z){
	threeDimVec vec;
	vec.x = x;
	vec.y = y;
	vec.z = z;
	return vec;
}

#endif /* TYPE_H_ */
