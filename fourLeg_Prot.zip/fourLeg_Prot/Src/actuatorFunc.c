/*
 * actuaterFunc.c
 *
 *  Created on: 2018/12/05
 *      Author: Sano
 */

// Includes
#include "actuatorFunc.h"

#define PI 3.14159265358979323846294338327

// Internal variables
const double _leg1_PWMCompare_0deg[3] = {765, 715, 750};
const double _leg2_PWMCompare_0deg[3] = {765, 710, 760};
const double _leg3_PWMCompare_0deg[3] = {715, 710, 730};
//const double _leg4_PWMCompare_0deg[3] = {720, 760, 770};
const double _leg4_PWMCompare_0deg[3] = {960, 760, 770};

const double _leg1_PWMCompare_90deg[3] = {2010, 2020, 1870};
const double _leg2_PWMCompare_90deg[3] = {2010, 1890, 1890};
const double _leg3_PWMCompare_90deg[3] = {2010, 1920, 1890};
const double _leg4_PWMCompare_90deg[3] = {2250, 1880, 1880};

const double _leg_length[3] = {59.55, 60.92, 97.48};

double _leg1_angle[3] = {0,0,0};
double _leg2_angle[3] = {0,0,0};
double _leg3_angle[3] = {0,0,0};
double _leg4_angle[3] = {0,0,0};

// Functions
void leg1_setJointAngle_rad (const double ang1, const double ang2, const double ang3){
	__HAL_TIM_SetCompare(&htim3,TIM_CHANNEL_2,_leg1_PWMCompare_90deg[0]/PI/2.0*ang1+_leg1_PWMCompare_0deg[0]);
	__HAL_TIM_SetCompare(&htim4,TIM_CHANNEL_1,_leg1_PWMCompare_90deg[1]/PI/2.0*ang2+_leg1_PWMCompare_0deg[1]);
	__HAL_TIM_SetCompare(&htim1,TIM_CHANNEL_2,_leg1_PWMCompare_90deg[2]/PI/2.0*ang3+_leg1_PWMCompare_0deg[2]);
}

void leg2_setJointAngle_rad (const double ang1, const double ang2, const double ang3){
	__HAL_TIM_SetCompare(&htim3,TIM_CHANNEL_4,-_leg2_PWMCompare_90deg[0]/PI/2.0*ang1+_leg2_PWMCompare_0deg[0]);
	__HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_4,_leg2_PWMCompare_90deg[1]/PI/2.0*ang2+_leg2_PWMCompare_0deg[1]);
	__HAL_TIM_SetCompare(&htim1,TIM_CHANNEL_4,_leg2_PWMCompare_90deg[2]/PI/2.0*ang3+_leg2_PWMCompare_0deg[2]);
}

void leg3_setJointAngle_rad (const double ang1, const double ang2, const double ang3){
	__HAL_TIM_SetCompare(&htim3,TIM_CHANNEL_3,_leg3_PWMCompare_90deg[0]/PI/2.0*ang1+_leg3_PWMCompare_0deg[0]);
	__HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_2,-_leg3_PWMCompare_90deg[1]/PI/2.0*ang2+_leg3_PWMCompare_0deg[1]);
	__HAL_TIM_SetCompare(&htim2,TIM_CHANNEL_1,-_leg3_PWMCompare_90deg[2]/PI/2.0*ang3+_leg3_PWMCompare_0deg[2]);
}

void leg4_setJointAngle_rad (const double ang1, const double ang2, const double ang3){
	__HAL_TIM_SetCompare(&htim4,TIM_CHANNEL_3,-_leg4_PWMCompare_90deg[0]/PI/2.0*ang1+_leg4_PWMCompare_0deg[0]);
	__HAL_TIM_SetCompare(&htim3,TIM_CHANNEL_1,-_leg4_PWMCompare_90deg[1]/PI/2.0*ang2+_leg4_PWMCompare_0deg[1]);
	__HAL_TIM_SetCompare(&htim4,TIM_CHANNEL_4,-_leg4_PWMCompare_90deg[2]/PI/2.0*ang3+_leg4_PWMCompare_0deg[2]);
}


void leg1_setPosition (const double rx, const double ry, const double rz){
	double tempC, tempS, ang1, ang2, ang3;
	tempC = (rx*rx+ry*ry+rz*rz-_leg_length[0]*_leg_length[0]-_leg_length[1]*_leg_length[1]-_leg_length[2]*_leg_length[2])/2/_leg_length[1]/_leg_length[2];
	tempS = -sqrt(fabs(1.0-tempC*tempC));		//+ -> -
	ang3 = atan2(tempS, tempC);

	tempS = -rx/sqrt(fabs(_leg_length[1]*_leg_length[1]+_leg_length[2]*_leg_length[2]+2.0*_leg_length[1]*_leg_length[2]*cos(ang3)));
	tempC = sqrt(fabs(1.0-tempS*tempS));		//+ <- -
	ang2 = atan2(tempS, tempC) - atan2(_leg_length[2]*sin(ang3), _leg_length[1]+_leg_length[2]*cos(ang3));

	ang1 = atan2(ry, -rz) - atan2(_leg_length[0], _leg_length[1]*cos(ang2)+_leg_length[2]*cos(ang2+ang3));

	leg1_setJointAngle_rad(ang1, ang2, ang3);
}

void leg2_setPosition (const double rx, const double ry, const double rz){
	double tempC, tempS, ang1, ang2, ang3;
	tempC = (rx*rx+ry*ry+rz*rz-_leg_length[0]*_leg_length[0]-_leg_length[1]*_leg_length[1]-_leg_length[2]*_leg_length[2])/2/_leg_length[1]/_leg_length[2];
	tempS = -sqrt(fabs(1.0-tempC*tempC));		//+ -> -
	ang3 = atan2(tempS, tempC);

	tempS = -rx/sqrt(fabs(_leg_length[1]*_leg_length[1]+_leg_length[2]*_leg_length[2]+2.0*_leg_length[1]*_leg_length[2]*cos(ang3)));
	tempC = sqrt(fabs(1.0-tempS*tempS));		//+ <- -
	ang2 = atan2(tempS, tempC) - atan2(_leg_length[2]*sin(ang3), _leg_length[1]+_leg_length[2]*cos(ang3));

	ang1 = atan2(ry, -rz) - atan2(_leg_length[0], _leg_length[1]*cos(ang2)+_leg_length[2]*cos(ang2+ang3));

	leg2_setJointAngle_rad(ang1, ang2, ang3);
}

void leg3_setPosition (const double rx, const double ry, const double rz){
	double tempC, tempS, ang1, ang2, ang3;
	tempC = (rx*rx+ry*ry+rz*rz-_leg_length[0]*_leg_length[0]-_leg_length[1]*_leg_length[1]-_leg_length[2]*_leg_length[2])/2/_leg_length[1]/_leg_length[2];
	tempS = sqrt(fabs(1.0-tempC*tempC));		//+ <- -
	ang3 = -atan2(tempS, tempC);

	tempS = -rx/sqrt(fabs(_leg_length[1]*_leg_length[1]+_leg_length[2]*_leg_length[2]+2.0*_leg_length[1]*_leg_length[2]*cos(ang3)));
	tempC = sqrt(fabs(1.0-tempS*tempS));		//+ <- -
	ang2 = atan2(tempS, tempC) - atan2(_leg_length[2]*sin(ang3), _leg_length[1]+_leg_length[2]*cos(ang3));

	ang1 = atan2(-ry, -rz) - atan2(_leg_length[0], _leg_length[1]*cos(ang2)+_leg_length[2]*cos(ang2+ang3));

	leg3_setJointAngle_rad(ang1, ang2, ang3);
}

void leg4_setPosition (const double rx, const double ry, const double rz){
	double tempC, tempS, ang1, ang2, ang3;
	tempC = (rx*rx+ry*ry+rz*rz-_leg_length[0]*_leg_length[0]-_leg_length[1]*_leg_length[1]-_leg_length[2]*_leg_length[2])/2/_leg_length[1]/_leg_length[2];
	tempS = sqrt(fabs(1.0-tempC*tempC));		//+ <- -
	ang3 = -atan2(tempS, tempC);

	tempS = -rx/sqrt(fabs(_leg_length[1]*_leg_length[1]+_leg_length[2]*_leg_length[2]+2.0*_leg_length[1]*_leg_length[2]*cos(ang3)));
	tempC = sqrt(fabs(1.0-tempS*tempS));		//+ <- -
	ang2 = atan2(tempS, tempC) - atan2(_leg_length[2]*sin(ang3), _leg_length[1]+_leg_length[2]*cos(ang3));

	ang1 = atan2(-ry, -rz) - atan2(_leg_length[0], _leg_length[1]*cos(ang2)+_leg_length[2]*cos(ang2+ang3));

	leg4_setJointAngle_rad(ang1, ang2, ang3);
}






