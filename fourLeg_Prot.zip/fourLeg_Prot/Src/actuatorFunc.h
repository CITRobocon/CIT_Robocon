/*
 * actuatorFunc.h
 *
 *  Created on: 2018/12/05
 *      Author: Sano
 */

#ifndef ACTUATORFUNC_H_
#define ACTUATORFUNC_H_

// Includes
#include "stm32f4xx_hal.h"
#include "math.h"

// External variables
extern SPI_HandleTypeDef hspi1;

extern TIM_HandleTypeDef htim1;
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim4;

extern UART_HandleTypeDef huart2;

// Functions
void leg1_setJointAngle_rad (const double, const double, const double);
void leg2_setJointAngle_rad (const double, const double, const double);
void leg3_setJointAngle_rad (const double, const double, const double);
void leg4_setJointAngle_rad (const double, const double, const double);

void leg1_setPosition (const double, const double, const double); //mm
void leg2_setPosition (const double, const double, const double);
void leg3_setPosition (const double, const double, const double);
void leg4_setPosition (const double, const double, const double);

//

//double getJointAngle (const int, const int);

#endif /* ACTUATORFUNC_H_ */
