/*
 * cubicCurve.h
 *
 *  Created on: 2018/12/27
 *      Author: Sano
 */

#ifndef CUBICCURVE_H_
#define CUBICCURVE_H_

typedef struct{
	double coe1;
	double coe2;
	double coe3;
	double coe4;
}cubicCoes;

double getVal_cubicCurve (cubicCoes, double);

cubicCoes hermite (double, double, double, double);

#endif /* CUBICCURVE_H_ */
