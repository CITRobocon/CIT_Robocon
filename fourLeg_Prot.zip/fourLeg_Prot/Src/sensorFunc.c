/*
 * sensorFunc.c
 *
 *  Created on: 2018/12/05
 *      Author: Sano
 */

// Includes
#include "sensorFunc.h"

// Funcions
int sw1IsOn (void){
	if(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_0) == 0)
		return 1;
	else
		return 0;
}

int sw2IsOn (void){
	if(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_2) == 0)
		return 1;
	else
		return 0;
}

int sw3IsOn (void){
	if(HAL_GPIO_ReadPin(GPIOC,GPIO_PIN_3) == 0)
		return 1;
	else
		return 0;
}
