/*
 * sensorFunc.h
 *
 *  Created on: 2018/12/05
 *      Author: Sano
 */

#ifndef SENSORFUNC_H_
#define SENSORFUNC_H_

// Includes
#include "stm32f4xx_hal.h"

// Functions
int sw1IsOn (void);

int sw2IsOn (void);

int sw3IsOn (void);

#endif /* SENSORFUNC_H_ */
