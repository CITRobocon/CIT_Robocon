/*
 * cubicCurve.c
 *
 *  Created on: 2018/12/27
 *      Author: Sano
 */
#include "cubicCurve.h"

double getVal_cubicCurve (cubicCoes coes, double u){
	return coes.coe1*u*u*u + coes.coe2*u*u + coes.coe3*u + coes.coe4;
}

cubicCoes hermite (double p0, double v0, double p1, double v1){
	cubicCoes coes;

	coes.coe1 = 2.0*p0 + v0 - 2.0*p1 + v1;
	coes.coe2 = -3.0*p0 - 2.0*v0 + 3.0*p1 - v1;
	coes.coe3 = v0;
	coes.coe4 = p0;

	return coes;
}

